<html> 
<head>
<title> Інформація, що надіслана за допомогою гіперпосилань </title>
</head>
<body>
<?php
$hobby=$_GET['hobby'];

?>
<ul>
<li> Хоббі: <b><?php echo $hobby ?></b></li>
</ul>
</body>
</html>