<!DOCTYPE html>
<html> 
<head>
<title> Інформація, що надіслана за допомогою гіперпосилань </title>
</head>
<body>
<?php
$first_name=$_GET['first_name'];
$last_name=$_GET['last_name'];
$home_phone=$_GET['home_phone'];
$email=$_GET['email'];
?>
<ul>
<li> Прізвище: <b><?php echo $first_name ?></b></li>
<li> Ім'я: <b><?php echo $last_name ?></b></li>
<li> Домашній телефон: <b><?php echo $home_phone ?></b></li>
<li> Електронна адреса: <b><?php echo $email ?></b></li>
</ul>
</body>
</html>